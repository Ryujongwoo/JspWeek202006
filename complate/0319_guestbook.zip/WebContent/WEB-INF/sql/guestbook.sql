CREATE TABLE "GUESTBOOK" (
  "IDX" NUMBER(*,0) NOT NULL, 
	"NAME" CHAR(20 BYTE) NOT NULL, 
	"PASSWORD" CHAR(20 BYTE) NOT NULL, 
	"MEMO" VARCHAR2(1000 BYTE) NOT NULL, 
	"WRITEDATE" TIMESTAMP (6) DEFAULT sysdate, 
	"IP" CHAR(15 BYTE), 
	PRIMARY KEY ("IDX")
);

delete from guestbook;
drop sequence guestbook_idx_seq;
create sequence guestbook_idx_seq;
commit;

select * from guestbook order by idx desc;

insert into guestbook (idx, name, password, memo, ip) values (guestbook_idx_seq.nextval, 'ȫ�浿', '1111', '1�� �Դϴ�.', '192.168.100.101');
insert into guestbook (idx, name, password, memo, ip) values (guestbook_idx_seq.nextval, '�Ӳ���', '2222', '2�� �Դϴ�.', '192.168.100.102');
insert into guestbook (idx, name, password, memo, ip) values (guestbook_idx_seq.nextval, '����', '3333', '3�� �Դϴ�.', '192.168.100.103');
insert into guestbook (idx, name, password, memo, ip) values (guestbook_idx_seq.nextval, '������', '4444', '4�� �Դϴ�.', '192.168.100.104');

select count(*) from guestbook;

select * from guestbook where memo like '%1��%' order by idx desc;
select count(*) from guestbook where memo like '%1��%';

select * from guestbook where name like '%��%' order by idx desc;
select count(*) from guestbook where name like '%��%';

select * from guestbook where name like '%�ٺ�%' or memo like '%�ٺ�%' order by idx desc;
select count(*) from guestbook where name like '%�ٺ�%' or memo like '%�ٺ�%';