SELECT * FROM memo;

# 자동증가 1부터 시작되게 하기
DELETE FROM memo;
ALTER TABLE memo AUTO_INCREMENT = 1;

INSERT INTO memo (NAME, PASSWORD, memo, ip) VALUES ('홍길동', '1111', '1등 입니다.', '192.168.2.101');
INSERT INTO memo (NAME, PASSWORD, memo, ip) VALUES ('임꺽정', '2222', '2등 입니다.', '192.168.2.102');
INSERT INTO memo (NAME, PASSWORD, memo, ip) VALUES ('장길산', '3333', '3등 입니다.', '192.168.2.103');
INSERT INTO memo (NAME, PASSWORD, memo, ip) VALUES ('일지매', '4444', '4등 입니다.', '192.168.2.104');