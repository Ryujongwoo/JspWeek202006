package com.koreait.service;

public class CategoryService {

	private static CategoryService instance = new CategoryService();
	private CategoryService() { }
	public static CategoryService getInstance() { return instance; }
	
	
	
}
