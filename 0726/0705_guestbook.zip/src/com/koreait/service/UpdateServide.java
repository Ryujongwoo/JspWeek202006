package com.koreait.service;

import java.sql.SQLException;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.koreait.dao.GuestbookDAO;
import com.koreait.ibatis.MyAppSqlConfig;
import com.koreait.vo.GuestbookVO;

public class UpdateServide {

	private static UpdateServide instance = new UpdateServide();
	private UpdateServide() { }
	public static UpdateServide getInstance() { return instance; }

//	updateOK.jsp에서 호출되는 수정할 데이터가 저장된 객체를 넘겨받고 mapper를 얻어온 후 dao 클래스의 update sql 명령을 실행하는
//	메소드를 호출하는 메소드
	public void update(GuestbookVO vo) {
		
		System.out.println("UpdateServide 클래스의 update() 메소드 실행");
		SqlMapClient mapper = MyAppSqlConfig.getSqlMapInstance();

		try {
			GuestbookDAO.getInstance().update(mapper, vo);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
}




